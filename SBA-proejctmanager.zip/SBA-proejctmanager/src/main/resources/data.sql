INSERT INTO `sbacogdb`.`user_db_tbl`
(
`user_id`,
`employee_id`,
`first_name`,
`last_name`)
VALUES
(1,
566666,
'U1',
'P1');

INSERT INTO `sbacogdb`.`user_db_tbl`
(`user_id`,
`employee_id`,
`first_name`,
`last_name`)
VALUES
(2,
577483,
'U2',
'P2');

INSERT INTO `sbacogdb`.`user_db_tbl`
(`user_id`,
`employee_id`,
`first_name`,
`last_name`)
VALUES
(3,
510910,
'U3',
'P3');

INSERT INTO `sbacogdb`.`user_db_tbl`
(`user_id`,
`employee_id`,
`first_name`,
`last_name`)
VALUES
(4,
520699,
'U4',
'P4');

INSERT INTO `sbacogdb`.`user_db_tbl`
(`user_id`,
`employee_id`,
`first_name`,
`last_name`)
VALUES
(5,
577489,
'U5',
'P5');

INSERT INTO `sbacogdb`.`project_db_tbl`
(`project_id`,
`end_date`,
`priority`,
`project_name`,
`start_date`,
`user_id`)
VALUES
(1,
CURDATE(),
10,
'PR1',
CURDATE(),
1);

INSERT INTO `sbacogdb`.`project_db_tbl`
(`project_id`,
`end_date`,
`priority`,
`project_name`,
`start_date`,
`user_id`)
VALUES
(2,
CURDATE(),
10,
'PR1',
CURDATE(),
1);

INSERT INTO `sbacogdb`.`project_db_tbl`
(`project_id`,
`end_date`,
`priority`,
`project_name`,
`start_date`,
`user_id`)
VALUES
(3,
CURDATE()+1,
10,
'PR2',
CURDATE()+3,
2);

INSERT INTO `sbacogdb`.`project_db_tbl`
(`project_id`,
`end_date`,
`priority`,
`project_name`,
`start_date`,
`user_id`)
VALUES
(4,
CURDATE(),
20,
'PR3',
CURDATE()+5,
2);

INSERT INTO `sbacogdb`.`project_db_tbl`
(`project_id`,
`end_date`,
`priority`,
`project_name`,
`start_date`,
`user_id`)
VALUES
(5,
CURDATE(),
15,
'PR4',
CURDATE()+10,
3);

INSERT INTO `sbacogdb`.`parent_task_db_tbl`
(`parent_id`,
`parent_task`,
`project_id`)
VALUES
(1,
'PO1',
1);

INSERT INTO `sbacogdb`.`parent_task_db_tbl`
(`parent_id`,
`parent_task`,
`project_id`)
VALUES
(2,
'PO2',
2);

INSERT INTO `sbacogdb`.`parent_task_db_tbl`
(`parent_id`,
`parent_task`,
`project_id`)
VALUES
(3,
'PO3',
1);

INSERT INTO `sbacogdb`.`parent_task_db_tbl`
(`parent_id`,
`parent_task`,
`project_id`)
VALUES
(4,
'PO4',
2);

INSERT INTO `sbacogdb`.`parent_task_db_tbl`
(`parent_id`,
`parent_task`,
`project_id`)
VALUES
(5,
'PO5',
1);


INSERT INTO `sbacogdb`.`task_db_tbl`
(`task_id`,
`end_date`,
`priority`,
`start_date`,
`status`,
`task_name`,
`parent_id`,
`project_id`,
`user_id`)
VALUES
(1,
CURDATE()+5,
5,
CURDATE(),
'New',
'Task1',
1,
1,
1);

INSERT INTO `sbacogdb`.`task_db_tbl`
(`task_id`,
`end_date`,
`priority`,
`start_date`,
`status`,
`task_name`,
`parent_id`,
`project_id`,
`user_id`)
VALUES
(2,
CURDATE()+5,
5,
CURDATE(),
'New',
'Task2',
2,
1,
2);

INSERT INTO `sbacogdb`.`task_db_tbl`
(`task_id`,
`end_date`,
`priority`,
`start_date`,
`status`,
`task_name`,
`parent_id`,
`project_id`,
`user_id`)
VALUES
(3,
CURDATE()+5,
5,
CURDATE(),
'New',
'Task3',
1,
2,
2);

INSERT INTO `sbacogdb`.`task_db_tbl`
(`task_id`,
`end_date`,
`priority`,
`start_date`,
`status`,
`task_name`,
`parent_id`,
`project_id`,
`user_id`)
VALUES
(4,
CURDATE()+5,
5,
CURDATE(),
'New',
'Task4',
1,
1,
1);

INSERT INTO `sbacogdb`.`task_db_tbl`
(`task_id`,
`end_date`,
`priority`,
`start_date`,
`status`,
`task_name`,
`parent_id`,
`project_id`,
`user_id`)
VALUES
(5,
CURDATE()+5,
5,
CURDATE(),
'New',
'Task5',
1,
2,
1);


