package com.cts.sba.iiht.projectmanager.service;

import java.util.List;
import com.cts.sba.iiht.projectmanager.entity.Project;

// TODO: Auto-generated Javadoc
/**
 * The Interface IProjectService.
 */
public interface IProjectService {
		
	/**
	 * Find all projects.
	 *
	 * @return the list
	 */
	public List<Project> findAllProjects();	
	
	/**
	 * Find all projects with task.
	 *
	 * @return the list
	 */
	public List<Project> findAllProjectsWithTask() ;

	/**
	 * Find project by id.
	 *
	 * @param projectId the project id
	 * @return the project
	 */
	public Project findProjectById(Long projectId);

	/**
	 * Adds the project.
	 *
	 * @param project the project
	 * @return the project
	 */
	public Project addProject(Project project);

	/**
	 * Update project.
	 *
	 * @param project the project
	 * @return the project
	 */
	public Project updateProject(Project project);
	
	/**
	 * Delete project.
	 *
	 * @param projectId the project id
	 */
	public void deleteProject(Long projectId);
	
	/**
	 * End project.
	 *
	 * @param projectId the project id
	 */
	public void endProject(Long projectId);

}
