/**

 *

 */

package com.cts.sba.iiht.projectmanager.entity;

import java.io.Serializable;
import java.util.Date;
import java.util.HashSet;
import java.util.Set;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;
import javax.persistence.Transient;
import javax.validation.constraints.Max;
import javax.validation.constraints.Min;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.fasterxml.jackson.annotation.OptBoolean;


// TODO: Auto-generated Javadoc
/**
 * The Class Project.
 */
@Entity
@Table(name = "Project_DB_TBL")
public class Project implements Serializable {

	/** The Constant serialVersionUID. */
	private static final long serialVersionUID = 1L;

	/** The project id. */
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "projectId", updatable = false, nullable = false)
	private long projectId;

	/** The project name. */
	private String projectName;

	/** The start date. */
	@Temporal(TemporalType.DATE)
	@JsonFormat(shape = JsonFormat.Shape.STRING, lenient = OptBoolean.FALSE, pattern = "yyyy-MM-dd", timezone = "CET")
	private Date startDate;

	/** The end date. */
	@Temporal(TemporalType.DATE)
	@JsonFormat(shape = JsonFormat.Shape.STRING, lenient = OptBoolean.FALSE, pattern = "yyyy-MM-dd", timezone = "CET")
	private Date endDate;

	/** The priority. */
	@Min(0) @Max(30)
	private int priority;
	
	/** The user. */
	@ManyToOne
	@JoinColumn(name = "user_id")
	private User user;
	
	/** The tasks. */
	@OneToMany(mappedBy = "project", cascade = CascadeType.ALL)
	private Set<Task> tasks = new HashSet<>();
	
	/** The parent tasks. */
	@OneToMany(mappedBy = "project", cascade = CascadeType.ALL)
	private Set<ParentTask> parentTasks = new HashSet<>();
	
	/** The count of tasks. */
	@Transient
	private Integer countOfTasks;
	
	/** The count of completed tasks. */
	@Transient
	private Integer countOfCompletedTasks;

	/**
	 * Gets the project id.
	 *
	 * @return the project id
	 */
	public long getProjectId() {
		return projectId;
	}

	/**
	 * Sets the project id.
	 *
	 * @param projectId the new project id
	 */
	public void setProjectId(long projectId) {
		this.projectId = projectId;
	}

	/**
	 * Gets the project name.
	 *
	 * @return the project name
	 */
	public String getProjectName() {
		return projectName;
	}

	/**
	 * Sets the project name.
	 *
	 * @param projectName the new project name
	 */
	public void setProjectName(String projectName) {
		this.projectName = projectName;
	}

	/**
	 * Gets the start date.
	 *
	 * @return the start date
	 */
	public Date getStartDate() {
		return startDate;
	}

	/**
	 * Sets the start date.
	 *
	 * @param startDate the new start date
	 */
	public void setStartDate(Date startDate) {
		this.startDate = startDate;
	}

	/**
	 * Gets the end date.
	 *
	 * @return the end date
	 */
	public Date getEndDate() {
		return endDate;
	}

	/**
	 * Sets the end date.
	 *
	 * @param endDate the new end date
	 */
	public void setEndDate(Date endDate) {
		this.endDate = endDate;
	}

	/**
	 * Gets the priority.
	 *
	 * @return the priority
	 */
	public int getPriority() {
		return priority;
	}

	/**
	 * Sets the priority.
	 *
	 * @param priority the new priority
	 */
	public void setPriority(int priority) {
		this.priority = priority;
	}

	/**
	 * Gets the user.
	 *
	 * @return the user
	 */
	public User getUser() {
		return user;
	}

	/**
	 * Sets the user.
	 *
	 * @param user the new user
	 */
	public void setUser(User user) {
		this.user = user;
	}
	
	/**
	 * Gets the tasks.
	 *
	 * @return the tasks
	 */
	public Set<Task> getTasks() {
		return tasks;
	}

	/**
	 * Sets the tasks.
	 *
	 * @param tasks the new tasks
	 */
	public void setTasks(Set<Task> tasks) {
		this.tasks = tasks;
	}

	/**
	 * Gets the parent tasks.
	 *
	 * @return the parent tasks
	 */
	public Set<ParentTask> getParentTasks() {
		return parentTasks;
	}

	/**
	 * Sets the parent tasks.
	 *
	 * @param parentTasks the new parent tasks
	 */
	public void setParentTasks(Set<ParentTask> parentTasks) {
		this.parentTasks = parentTasks;
	}

	/**
	 * Gets the count of tasks.
	 *
	 * @return the count of tasks
	 */
	public Integer getCountOfTasks() {
		return countOfTasks;
	}

	/**
	 * Sets the count of tasks.
	 *
	 * @param countOfTasks the new count of tasks
	 */
	public void setCountOfTasks(Integer countOfTasks) {
		this.countOfTasks = countOfTasks;
	}

	/**
	 * Gets the count of completed tasks.
	 *
	 * @return the count of completed tasks
	 */
	public Integer getCountOfCompletedTasks() {
		return countOfCompletedTasks;
	}

	/**
	 * Sets the count of completed tasks.
	 *
	 * @param countOfCompletedTasks the new count of completed tasks
	 */
	public void setCountOfCompletedTasks(Integer countOfCompletedTasks) {
		this.countOfCompletedTasks = countOfCompletedTasks;
	}

	/**
	 * Instantiates a new project.
	 *
	 * @param projectId the project id
	 * @param projectName the project name
	 * @param startDate the start date
	 * @param endDate the end date
	 * @param priority the priority
	 * @param user the user
	 */
	public Project(long projectId, String projectName, Date startDate, Date endDate, int priority, User user) {
		super();
		this.projectId = projectId;
		this.projectName = projectName;
		this.startDate = startDate;
		this.endDate = endDate;
		this.priority = priority;
		this.user = user;
	}

	/**
	 * To string.
	 *
	 * @return the string
	 */
	@Override
	public String toString() {
		return "Project [projectId=" + projectId + ", projectName=" + projectName + ", startDate=" + startDate
				+ ", endDate=" + endDate + ", priority=" + priority + "]";
	}

	/**
	 * Instantiates a new project.
	 */
	public Project() {
		super();
	}

}
