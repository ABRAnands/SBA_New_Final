package com.cts.sba.iiht.projectmanager.service;

import java.util.List;

import com.cts.sba.iiht.projectmanager.entity.ParentTask;

// TODO: Auto-generated Javadoc
/**
 * The Interface IParentTaskService.
 */
public interface IParentTaskService {
	
	/**
	 * Adds the parent task.
	 *
	 * @param parentTask the parent task
	 * @return the parent task
	 */
	public ParentTask addParentTask(ParentTask parentTask);
	
	/**
	 * Find parent task by id.
	 *
	 * @param parentTaskId the parent task id
	 * @return the parent task
	 */
	public ParentTask findParentTaskById(Long parentTaskId);
	
	/**
	 * Find all parent tasks.
	 *
	 * @return the list
	 */
	public List<ParentTask> findAllParentTasks();
	
	/**
	 * 
	 */
	
	public void deleteParentTask(Long id); 

}
