/**

 *

 */

package com.cts.sba.iiht.projectmanager.entity;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonProperty.Access;


// TODO: Auto-generated Javadoc
/**
 * The Class Task.
 */
@Entity
@Table(name = "Task_DB_TBL")
public class Task implements Serializable {

	/** The Constant serialVersionUID. */
	private static final long serialVersionUID = 1L;

	/** The task id. */
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "taskId", updatable = false, nullable = false)
	private long taskId;

	/** The task name. */
	private String taskName;

	/** The start date. */
	private Date startDate;

	/** The end date. */
	private Date endDate;

	/** The priority. */
	private int priority;

	/** The status. */
	private String status;

	/** The parent task. */
	@ManyToOne/*(cascade=CascadeType.ALL)*/	
	@JoinColumn(name = "parent_id")
	private ParentTask parentTask;

	/** The user. */
	@ManyToOne
	@JoinColumn(name = "user_id")
	private User user;
	
	/** The project. */
	@ManyToOne
	@JsonProperty(access = Access.WRITE_ONLY)
	@JoinColumn(name = "project_id")
	private Project project;

	/**
	 * Gets the task id.
	 *
	 * @return the task id
	 */
	public long getTaskId() {
		return taskId;
	}

	/**
	 * Sets the task id.
	 *
	 * @param taskId the new task id
	 */
	public void setTaskId(long taskId) {
		this.taskId = taskId;
	}

	/**
	 * Gets the task name.
	 *
	 * @return the task name
	 */
	public String getTaskName() {
		return taskName;
	}

	/**
	 * Sets the task name.
	 *
	 * @param taskName the new task name
	 */
	public void setTaskName(String taskName) {
		this.taskName = taskName;
	}

	/**
	 * Gets the start date.
	 *
	 * @return the start date
	 */
	public Date getStartDate() {
		return startDate;
	}

	/**
	 * Sets the start date.
	 *
	 * @param startDate the new start date
	 */
	public void setStartDate(Date startDate) {
		this.startDate = startDate;
	}

	/**
	 * Gets the end date.
	 *
	 * @return the end date
	 */
	public Date getEndDate() {
		return endDate;
	}

	/**
	 * Sets the end date.
	 *
	 * @param endDate the new end date
	 */
	public void setEndDate(Date endDate) {
		this.endDate = endDate;
	}

	/**
	 * Gets the priority.
	 *
	 * @return the priority
	 */
	public int getPriority() {
		return priority;
	}

	/**
	 * Sets the priority.
	 *
	 * @param priority the new priority
	 */
	public void setPriority(int priority) {
		this.priority = priority;
	}

	/**
	 * Gets the status.
	 *
	 * @return the status
	 */
	public String getStatus() {
		return status;
	}

	/**
	 * Sets the status.
	 *
	 * @param status the new status
	 */
	public void setStatus(String status) {
		this.status = status;
	}

	/**
	 * Gets the parent task.
	 *
	 * @return the parent task
	 */
	public ParentTask getParentTask() {
		return parentTask;
	}

	/**
	 * Sets the parent task.
	 *
	 * @param parentTask the new parent task
	 */
	public void setParentTask(ParentTask parentTask) {
		this.parentTask = parentTask;
	}
	
	/**
	 * Gets the project.
	 *
	 * @return the project
	 */
	@JsonIgnore
	public Project getProject() {
		return project;
	}

	/**
	 * Sets the project.
	 *
	 * @param project the new project
	 */
	public void setProject(Project project) {
		this.project = project;
	}

	/**
	 * Gets the user.
	 *
	 * @return the user
	 */
	public User getUser() {
		return user;
	}

	/**
	 * Sets the user.
	 *
	 * @param user the new user
	 */
	public void setUser(User user) {
		this.user = user;
	}

	/**
	 * Instantiates a new task.
	 *
	 * @param taskName the task name
	 * @param startDate the start date
	 * @param endDate the end date
	 * @param priority the priority
	 * @param status the status
	 * @param parentTask the parent task
	 * @param project the project
	 */
	public Task(String taskName, Date startDate, Date endDate, int priority, String status, ParentTask parentTask,
			Project project) {
		super();
		this.taskName = taskName;
		this.startDate = startDate;
		this.endDate = endDate;
		this.priority = priority;
		this.status = status;
		this.parentTask = parentTask;
		this.project = project;
	}

	/**
	 * Instantiates a new task.
	 */
	public Task() {
		super();
	}

}
