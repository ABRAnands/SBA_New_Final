package com.cts.sba.iiht.projectmanager.service.impl;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.cts.sba.iiht.projectmanager.entity.User;
import com.cts.sba.iiht.projectmanager.repository.IUserRepository;
import com.cts.sba.iiht.projectmanager.service.IUserService;

// TODO: Auto-generated Javadoc
/**
 * The Class UserServiceImpl.
 */
@Service
public class UserServiceImpl implements IUserService {

	/** The user repo. */
	@Autowired
	IUserRepository userRepo;
	
	/**
	 * Adds the user.
	 *
	 * @param user the user
	 * @return the user
	 */
	@Transactional
	@Override
	public User addUser(User user) {
		if (user != null) {
			Optional<User> optUser = userRepo.findByEmployeeId(user.getEmployeeId());
			if(optUser.isPresent()) {
				throw new RuntimeException("Employee Id already exists");
			}			
			return userRepo.save(user);
		}
		return null;

	}
	
	/**
	 * Update user.
	 *
	 * @param user the user
	 * @return the user
	 */
	@Transactional
	@Override
	public User updateUser(User user) {
		
		Optional<User> optUser = userRepo.findByEmployeeId(user.getEmployeeId());
			if(optUser.isPresent()) {				
				throw new RuntimeException("Employee Id already exists");				
			}
		
			return userRepo.save(user);

	}

	/**
	 * Delete user.
	 *
	 * @param userId the user id
	 */
	@Transactional
	@Override
	public void deleteUser(Long userId) {
		userRepo.deleteById(userId);

	}

	/**
	 * Find user by id.
	 *
	 * @param userId the user id
	 * @return the user
	 */
	@Override
	public User findUserById(Long userId) {
		Optional<User> user = userRepo.findById(userId);
		return user.isPresent() ? user.get() : null;
	}

	/**
	 * Find all users.
	 *
	 * @return the list
	 */
	@Override
	public List<User> findAllUsers() {
		return userRepo.findAll();
	}

}
