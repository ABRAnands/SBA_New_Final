package com.cts.sba.iiht;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;

import com.cts.sba.iiht.projectmanager.entity.ParentTask;
import com.cts.sba.iiht.projectmanager.entity.Project;
import com.cts.sba.iiht.projectmanager.entity.Task;
import com.cts.sba.iiht.projectmanager.entity.User;


// TODO: Auto-generated Javadoc
/**
 * The Class ApplicationTestData.
 */
public class ApplicationTestData {
	
	/**
	 * Gets the project data to read.
	 *
	 * @return the project data to read
	 */
	public static Project getProjectDataToRead() {
		Project project = new Project(1, "FSA work related changes in all screens.", dateFromString("08/31/2019")
				, dateFromString("11/26/2019"), 9, getUserDataToRead());
		return project;
	}
	
	/**
	 * Gets the project data to write.
	 *
	 * @return the project data to write
	 */
	public static Project getProjectDataToWrite() {
		Project project = new Project();
		project.setPriority(12);
		project.setProjectName("Update Fee processing changes.");
		project.setStartDate(dateFromString("08/31/2019"));
		project.setEndDate(dateFromString("10/12/2019"));
		project.setUser(getUserDataToRead());
		
		return project;
	}
	
	/**
	 * Gets the user data to read.
	 *
	 * @return the user data to read
	 */
	public static User getUserDataToRead() {
		User user = new User();
		user.setEmployeeId(533333);
		user.setFirstName("Abhishek");
		user.setLastName("Anand");
		user.setUserId(1);
		
		return user;
	}
	
	/**
	 * Gets the user data to write.
	 *
	 * @return the user data to write
	 */
	public static User getUserDataToWrite() {
		User user = new User("Supe", "Rucha", 577483);
		return user;
	}
	
	/**
	 * Gets the task data to read.
	 *
	 * @return the task data to read
	 */
	public static Task getTaskDataToRead() {
		Task task = new Task();
		
		task.setTaskId(12);
		task.setPriority(8);
		task.setTaskName("Child task for checkbox validation after task creation on load ");
		task.setStartDate(dateFromString("08/31/2019"));
		task.setEndDate(dateFromString("11/26/2019"));
		task.setStatus("New");
		task.setUser(getUserDataToRead());
		
		return task;
	}
	
	/**
	 * Gets the task data to write.
	 *
	 * @return the task data to write
	 */
	public static Task getTaskDataToWrite() {
		Task task = new Task("Testing task for Junit Test.", dateFromString("09/22/2019"), dateFromString("12/11/2019"), 
				24, "New", getParentTaskDataToRead(), getProjectDataToRead());
		
		return task;
	}
	
	/**
	 * Gets the parent task data to read.
	 *
	 * @return the parent task data to read
	 */
	public static ParentTask getParentTaskDataToRead() {
		ParentTask parentTask = new ParentTask(9, "Parent task for checkbox validation on load after task creation");
		return parentTask;
	}
	
	/**
	 * Gets the parent task data to write.
	 *
	 * @return the parent task data to write
	 */
	public static ParentTask getParentTaskDataToWrite() {
		ParentTask parentTask = new ParentTask();
		
		parentTask.setParentTask("Testing parent task for Junit validation.");
		//parentTask.setProject(getProjectDataToRead());
		
		return parentTask;
	}
	
	/**
	 * Date from string.
	 *
	 * @param sDate the s date
	 * @return the date
	 */
	public static Date dateFromString(final String sDate) {
		String dateFormat = "MM/dd/yyyy";
		final SimpleDateFormat sdf = new SimpleDateFormat(dateFormat, Locale.US);
		try {
			return sdf.parse(sDate);
		} catch (ParseException e) {
			e.printStackTrace();
		}
		return null;
	}

}
