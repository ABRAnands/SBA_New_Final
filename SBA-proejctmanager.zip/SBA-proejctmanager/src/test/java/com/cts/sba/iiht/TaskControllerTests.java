package com.cts.sba.iiht;

import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.Spy;
import org.mockito.junit.MockitoJUnitRunner;
import org.springframework.http.MediaType;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.MvcResult;
import org.springframework.test.web.servlet.request.MockMvcRequestBuilders;
import org.springframework.test.web.servlet.result.MockMvcResultMatchers;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;

import com.cts.sba.iiht.projectmanager.controller.TaskManagerController;
import com.cts.sba.iiht.projectmanager.entity.ParentTask;
import com.cts.sba.iiht.projectmanager.entity.Task;
import com.cts.sba.iiht.projectmanager.service.IParentTaskService;
import com.cts.sba.iiht.projectmanager.service.ITaskService;
import com.fasterxml.jackson.databind.ObjectMapper;

// TODO: Auto-generated Javadoc
/**
 * The Class TaskControllerTests.
 */
@RunWith(MockitoJUnitRunner.class)
public class TaskControllerTests {
	
	/**
	 * Instantiates a new task controller tests.
	 */
	public TaskControllerTests() {
	}
	
	/** The service. */
	@Mock
	private ITaskService service;
	
	/** The parent task service. */
	@Mock
	private IParentTaskService parentTaskService;

	/** The mock mvc. */
	private MockMvc mockMvc;

	/** The controller. */
	@Spy
	@InjectMocks
	private TaskManagerController controller = new TaskManagerController();

	/**
	 * Inits the.
	 */
	@Before
	public void init() {
		mockMvc = MockMvcBuilders.standaloneSetup(controller).build();
	}
	
	/**
	 * Test get task by id.
	 *
	 * @throws Exception the exception
	 */
	@Test
	public void testGetTaskById() throws Exception {
		Task task = ApplicationTestData.getTaskDataToRead();
		
		Mockito.when(service.findTask(Mockito.anyLong())).thenReturn(task);
		
		mockMvc.perform(MockMvcRequestBuilders.get("/tasks/12"))
			.andExpect(MockMvcResultMatchers.status().is(200))
			.andExpect(MockMvcResultMatchers.jsonPath("$.taskId").value(12));
	}
	
	/**
	 * Test add task.
	 *
	 * @throws Exception the exception
	 */
	@Test
	public void testAddTask() throws Exception {
		Task task = ApplicationTestData.getTaskDataToWrite();
		
		ObjectMapper mapper = new ObjectMapper();
		String jsonString = mapper.writeValueAsString(task);
		
		MvcResult result = mockMvc
				.perform(MockMvcRequestBuilders.post("/tasks").content(jsonString)
						.contentType(MediaType.APPLICATION_JSON))
				.andExpect(MockMvcResultMatchers.status().is(200)).andReturn();
		Assert.assertEquals(200, result.getResponse().getStatus());
	}
	
	/**
	 * Test update task.
	 *
	 * @throws Exception the exception
	 */
	@Test
	public void testUpdateTask() throws Exception {
		Task task = ApplicationTestData.getTaskDataToRead();
		
		ObjectMapper mapper = new ObjectMapper();
		String jsonString = mapper.writeValueAsString(task);
		
		mockMvc.perform(
				MockMvcRequestBuilders.put("/tasks").content(jsonString).contentType(MediaType.APPLICATION_JSON))
				.andExpect(MockMvcResultMatchers.status().is(200));
	}
	
	/**
	 * Test delete task byid.
	 *
	 * @throws Exception the exception
	 */
	@Test
	public void testDeleteTaskByid() throws Exception {
		/*Task task = ApplicationTestData.getTaskDataToRead();
		
		Mockito.when(service.findTask(Mockito.anyLong())).thenReturn(task);
		Mockito.doNothing().when(service).deleteTask(Mockito.anyLong());
		
		mockMvc.perform(MockMvcRequestBuilders.delete("/tasks/12")).andExpect(MockMvcResultMatchers.status().is(200));*/
	}
	
	/**
	 * Test delete task when un success.
	 *
	 * @throws Exception the exception
	 */
	@Test
	public void testDeleteTask_WhenUnSuccess() throws Exception {
		/*Task task = null;
		Mockito.when(service.findTask(Mockito.anyLong())).thenReturn(task);
		//mockMvc.perform(MockMvcRequestBuilders.delete("/tasks/0")).andExpect(MockMvcResultMatchers.status().is(404));*/
	}
	
	/**
	 * Test get task when un success.
	 *
	 * @throws Exception the exception
	 */
	@Test
	public void testGetTask_WhenUnSuccess() throws Exception {
		/*Task task = null;

		Mockito.when(service.findTask(Mockito.anyLong())).thenReturn(task);
		
		/*mockMvc.perform(MockMvcRequestBuilders.get("/tasks/0"))
			.andExpect(MockMvcResultMatchers.status().is(404));*/

	}
	
	/**
	 * Test get all tasks.
	 *
	 * @throws Exception the exception
	 */
	@Test
	public void testGetAllTasks() throws Exception {
		
		mockMvc.perform(MockMvcRequestBuilders.get("/tasks"))
			.andExpect(MockMvcResultMatchers.status().is(200));
	}
	
	/**
	 * Test get parent task by id.
	 *
	 * @throws Exception the exception
	 */
	@Test
	public void testGetParentTaskById() throws Exception {
		/*ParentTask parentTask = ApplicationTestData.getParentTaskDataToRead();

		Mockito.when(parentTaskService.findParentTaskById(Mockito.anyLong())).thenReturn(parentTask);

		/*mockMvc.perform(MockMvcRequestBuilders.get("/ptasks/9")).andExpect(MockMvcResultMatchers.status().is(200))
				.andExpect(MockMvcResultMatchers.jsonPath("$.parentId").value(9));*/
	}

	/**
	 * Test add parent task.
	 *
	 * @throws Exception the exception
	 */
	@Test
	public void testAddParentTask() throws Exception {
		ParentTask parentTask = ApplicationTestData.getParentTaskDataToWrite();

		ObjectMapper mapper = new ObjectMapper();
		String jsonString = mapper.writeValueAsString(parentTask);

		MvcResult result = mockMvc
				.perform(MockMvcRequestBuilders.post("/ptasks").content(jsonString)
						.contentType(MediaType.APPLICATION_JSON))
				.andExpect(MockMvcResultMatchers.status().is(200)).andReturn();
		Assert.assertEquals(200, result.getResponse().getStatus());
	}

	/**
	 * Test get all parent tasks.
	 *
	 * @throws Exception the exception
	 */
	@Test
	public void testGetAllParentTasks() throws Exception {

		mockMvc.perform(MockMvcRequestBuilders.get("/ptasks")).andExpect(MockMvcResultMatchers.status().is(200));
	}
	
	/**
	 * Test get parent task when un success.
	 *
	 * @throws Exception the exception
	 */
	@Test
	public void testGetParentTask_WhenUnSuccess() throws Exception {
		/*ParentTask parentTask = null;

		Mockito.when(parentTaskService.findParentTaskById(Mockito.anyLong())).thenReturn(parentTask);

		//mockMvc.perform(MockMvcRequestBuilders.get("/ptasks/0")).andExpect(MockMvcResultMatchers.status().is(404));*/

	}

}
