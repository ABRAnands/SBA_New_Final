package com.cts.sba.iiht;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit4.SpringRunner;


// TODO: Auto-generated Javadoc
/**
 * The Class ProjectmanagerApplicationTests.
 */
@RunWith(SpringRunner.class)
@SpringBootTest
class ProjectmanagerApplicationTests {

	/**
	 * Context loads.
	 */
	@Test
	void contextLoads() {
	}
	
	/**
	 * Main method.
	 */
	/*@Test
	public void mainMethod() {
		ProjectmanagerApplication.main(new String[] {});
	}*/

}
