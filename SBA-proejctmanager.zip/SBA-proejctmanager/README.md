# SBA-projectmanagerservice

This is back end service for project manager application.

Build application using mvn clean package command

Once build is successful, run command "java -jar project-manager.jar" on target folder to start the application