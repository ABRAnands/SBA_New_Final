import { FilterTasksPipe } from './filter-tasks.pipe';

describe('FilterTasksPipe', () => {
  it('create an instance', () => {
    const pipe = new FilterTasksPipe();
    expect(pipe).toBeTruthy();
  });
});
