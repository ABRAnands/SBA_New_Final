import { ProjectPipe } from './project.pipe';

describe('ProjectPipe', () => {
  it('create an instance', () => {
    const pipe = new ProjectPipe();
    expect(pipe).toBeTruthy();
  });
});
