import { User } from '../model/user';
import { Task } from '../model/task';
import { ParentTask } from '../model/parent-task';

export class Project {
  projectId: number;
  projectName: string;
  startDate: any;
  endDate: any;
  priority: number;
  completed: any;
  user: User;
  tasks: Task[];
  parentTasks: ParentTask[];
  countOfTasks: number;
  countOfCompletedTasks: number;
  }
