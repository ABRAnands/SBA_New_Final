import { ParentTask } from 'src/app/model/parent-task';
import { Project } from 'src/app/model/project';
import { User } from 'src/app/model/user';

export class Task {
  taskId: number;
  taskName: string;
  startDate: any;
  endDate: any;
  priority: number;
  status: any;
  user: User;
  project: Project;
  parentTask: ParentTask;  
}
