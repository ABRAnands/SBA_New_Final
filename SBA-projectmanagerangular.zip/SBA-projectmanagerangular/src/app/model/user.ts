export class User {
  userId: number;
  employeeId: number;
  firstName: string;
  lastName: string;
}
