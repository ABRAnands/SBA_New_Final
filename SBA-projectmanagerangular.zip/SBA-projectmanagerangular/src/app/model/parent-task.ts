import { Project } from './project';

export class ParentTask {
    parentId: number;
    parentTask: string;
    project:Project;
}
