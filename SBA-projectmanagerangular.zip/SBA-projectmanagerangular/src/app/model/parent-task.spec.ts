import { ParentTask } from './parent-task';

describe('ParentTask', () => {
  it('should create an instance', () => {
    expect(new ParentTask()).toBeTruthy();
  });
});
